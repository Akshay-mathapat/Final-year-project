/**
 * Migration script to add new fields to students table
 * Run this script to add all the new academic and personal fields
 */

const { db, execute, query } = require('./config/sqlite-database');

async function migrateStudentTable() {
  console.log('🔄 Migrating students table to add new fields...\n');
  
  try {
    // List of new fields to add
    const newFields = [
      { name: 'aadhar_number', type: 'TEXT', nullable: true },
      { name: 'date_of_birth', type: 'TEXT', nullable: true },
      { name: 'category', type: 'TEXT', nullable: true },
      { name: 'tenth_percentage', type: 'REAL', nullable: true },
      { name: 'tenth_year_of_passing', type: 'TEXT', nullable: true },
      { name: 'diploma_or_puc', type: 'TEXT', nullable: true },
      { name: 'puc_percentage', type: 'REAL', nullable: true },
      { name: 'puc_year_of_passing', type: 'TEXT', nullable: true },
      { name: 'be_sgpa_first_sem', type: 'REAL', nullable: true },
      { name: 'be_sgpa_second_sem', type: 'REAL', nullable: true },
      { name: 'first_year_cgpa', type: 'REAL', nullable: true },
      { name: 'be_sgpa_third_sem', type: 'REAL', nullable: true },
      { name: 'be_sgpa_fourth_sem', type: 'REAL', nullable: true },
      { name: 'second_year_cgpa', type: 'REAL', nullable: true },
      { name: 'be_sgpa_fifth_sem', type: 'REAL', nullable: true },
      { name: 'be_sgpa_sixth_sem', type: 'REAL', nullable: true },
      { name: 'third_year_cgpa', type: 'REAL', nullable: true },
      { name: 'overall_be_percentage', type: 'REAL', nullable: true },
      { name: 'be_year_of_passing', type: 'TEXT', nullable: true },
      { name: 'has_backlogs', type: 'TEXT', nullable: true },
      { name: 'backlog_count', type: 'INTEGER', nullable: true }
    ];

    // Check existing columns
    const existingColumns = await query(`PRAGMA table_info(students)`);
    const existingColumnNames = existingColumns.map(col => col.name.toLowerCase());

    // Add new columns that don't exist
    for (const field of newFields) {
      const fieldNameLower = field.name.toLowerCase();
      if (!existingColumnNames.includes(fieldNameLower)) {
        try {
          await execute(
            `ALTER TABLE students ADD COLUMN ${field.name} ${field.type}`
          );
          console.log(`✅ Added column: ${field.name}`);
        } catch (error) {
          console.error(`❌ Error adding column ${field.name}:`, error.message);
        }
      } else {
        console.log(`⏭️  Column already exists: ${field.name}`);
      }
    }

    console.log('\n✅ Migration completed successfully!');
    
  } catch (error) {
    console.error('❌ Migration failed:', error.message);
    throw error;
  } finally {
    db.close();
  }
}

// Run migration
migrateStudentTable()
  .then(() => {
    console.log('\n🎉 Database migration completed!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n💥 Migration error:', error);
    process.exit(1);
  });

